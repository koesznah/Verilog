<h1>HDLBits Verilog Solutions  <img src="https://visitor-badge.glitch.me/badge?page_id=Adrofier.HDLBits-Verilog-Solutions"> <img src="https://img.shields.io/static/v1.svg?label=%E2%AD%90&message=If%20Useful&color=blue"> </h1>
<p align="center">
  <a href="https://hdlbits.01xz.net/wiki/Main_Page">
    <img src="https://hdlbits.01xz.net/images/logo270.png" alt="Logo" width="70" height="70">
  </a> 
</p>

This repository contains my solutions to all the problems of the HDL-Bits Verilog problem set.<br>
At the time of making this, the problem set had a total of 178 questions.

## Contributors
Adarsh Pal - <adarshpal999@gmail.com>
